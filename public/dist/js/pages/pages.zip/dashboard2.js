$(function () {

    'use strict';


    var charts_activation = {
        init: function (sent_url,model) {
            // -- Set new default font family and font color to mimic Bootstrap's default styling
            Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
            Chart.defaults.global.defaultFontColor = '#292b2c';

            this.ajaxGetSalesData(sent_url,model);

        },

        ajaxGetSalesData: function (sent_url,model) {
            var urlPath =  window.location.origin +'/'+sent_url+'/'+model;
            /*console.log(urlPath);*/
            var request = $.ajax( {
                method: 'GET',
                url: urlPath
            } );

            request.done( function ( response ) {
                charts_activation.createCompletedActivationChart( response );
            });
        },

        /**
         * Created the Completed Jobs Chart
         */
        createCompletedActivationChart: function ( response ) {

            var all_labels = Object.values(response.all_labels);
            var all_data_smart = Object.values(response.all_data_smart);
            var all_data_feature = Object.values(response.all_data_feature);
            var progress = document.getElementById('animationProgress');
            var activationChartCanvas = $('#activationChart').get(0).getContext('2d');
            // This will get the first returned node in the jQuery collection.
            var activationChart = new Chart(activationChartCanvas);
            var activationChartData = {
                labels: all_labels,
                datasets: [
                    {
                        label: 'Feature Phone',
                        fillColor: 'rgba(115, 24, 32, .7)',
                        strokeColor: 'rgba(115, 24, 32, .8)',
                        pointColor: '#ba0e06',
                        pointStrokeColor: 'rgba(115, 24, 32,1)',
                        pointHighlightFill: '#fff',
                        pointHighlightStroke: 'rgba(115, 24, 32,1)',
                        data                : all_data_smart
                    },
                    {
                        label: 'Smart Phone',
                        fillColor: 'rgba(18, 119, 137, .7)',
                        strokeColor: 'rgba(18, 119, 137,0.5)',
                        pointColor: 'rgba(18, 119, 137,1)',
                        pointStrokeColor: '#c1c7d1',
                        pointHighlightFill: '#fff',
                        pointHighlightStroke: 'rgba(18, 119, 137,1)',
                        data                : all_data_feature
                    }
                ],
                options: {
                    title:{
                        display:true,
                        text: "Chart.js Line Chart - Animation Progress Bar"
                    },
                animation: {
                    duration: 20,
                    onProgress: function (animation) {
                        progress.value = animation.currentStep / animation.numSteps;
                    },
                    onComplete: function (animation) {
                        window.setTimeout(function () {
                            progress.value = 0;
                        }, 20);
                    }
                }
            }
            };

            var activationChartOptions = {
                // Boolean - If we should show the scale at all
                showScale: true,
                // Boolean - Whether grid lines are shown across the chart
                scaleShowGridLines: true,
                // String - Colour of the grid lines
                scaleGridLineColor: 'rgba(0,0,0,.2)',
                // Number - Width of the grid lines
                scaleGridLineWidth: 1,
                // Boolean - Whether to show horizontal lines (except X axis)
                scaleShowHorizontalLines: true,
                // Boolean - Whether to show vertical lines (except Y axis)
                scaleShowVerticalLines: true,
                // Boolean - Whether the line is curved between points
                bezierCurve: true,
                // Number - Tension of the bezier curve between points
                bezierCurveTension: 0.3,
                // Boolean - Whether to show a dot for each point
                pointDot: true,
                // Number - Radius of each point dot in pixels
                pointDotRadius: 1,
                // Number - Pixel width of point dot stroke
                pointDotStrokeWidth: 1,
                // Number - amount extra to add to the radius to cater for hit detection outside the drawn point
                pointHitDetectionRadius: 20,
                // Boolean - Whether to show a stroke for datasets
                datasetStroke: true,
                // Number - Pixel width of dataset stroke
                datasetStrokeWidth: 2,
                // Boolean - Whether to fill the dataset with a color
                datasetFill: true,
                // String - A legend template
                legendTemplate: '<ul class=\'<%=name.toLowerCase()%>-legend\'><% for (var i=0; i<datasets.length; i++){%><li><span style=\'background-color:<%=datasets[i].lineColor%>\'></span><%=datasets[i].label%></li><%}%></ul>',
                // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
                maintainAspectRatio: true,
                // Boolean - whether to make the chart responsive to window resizing
                responsive: true,
                scaleFontColor: "rgb(184,199,206)"
            };

            activationChart.Line(activationChartData, activationChartOptions);
        }
    };

    var sent_url = "activationChartTwentyFour";
    var model = "all_models";
    charts_activation.init(sent_url,model);
    /*console.log(sent_url,model);*/

    $(document).ready(function() {
        $("#ActivationChartID").change(function(){
            model = $('#ActivationChartID_Model option:selected').val();
            sent_url = $('#ActivationChartID option:selected').val();
            if(model==""){
                model = "all_models";
            }

            if(sent_url=="activationChartTwentyFour"){
                document.getElementById('title2').innerHTML = "Last 24 Hours";
            }else if(sent_url=="activationChartLastSevenDays"){
                document.getElementById('title2').innerHTML = "Last 7 Days";
            }else if(sent_url=="activationChartLastThirtyDays"){
                document.getElementById('title2').innerHTML = "Last 30 Days";
            }else if(sent_url=="activationChartCurrentWeek"){
                document.getElementById('title2').innerHTML = "Current Week";
            }else if(sent_url=="activationChartPreviousWeek"){
                document.getElementById('title2').innerHTML = "Previous Week";
            }else if(sent_url=="activationChartCurrentMonth"){
                document.getElementById('title2').innerHTML = "Current Month";
            }else if(sent_url=="activationChartPreviousMonth"){
                document.getElementById('title2').innerHTML = "Previous Month";
            }else if(sent_url=="activationChartYear"){
                document.getElementById('title2').innerHTML = "Current Year";
            }
            $('#refresh_main').load('dashboard #refresh', function() {

            });
            charts_activation.init(sent_url,model);
        });
    });

    $(document).ready(function() {
        $("#ActivationChartID_Model").change(function(){
            model = $('#ActivationChartID_Model option:selected').val();
            sent_url = $('#ActivationChartID option:selected').val();
            if(sent_url==""){
                sent_url = "activationChartTwentyFour";
            }

            document.getElementById('title1').innerHTML = model;

            $('#refresh_main').load('dashboard #refresh', function() {

            });
            charts_activation.init(sent_url,model);
        });
    });




    $('.sparkbar').each(function () {
        var $this = $(this);
        $this.sparkline('html', {
            type: 'bar',
            height: $this.data('height') ? $this.data('height') : '30',
            barColor: $this.data('color')
        });
    });

    // -----------------
    // - SPARKLINE PIE -
    // -----------------
    $('.sparkpie').each(function () {
        var $this = $(this);
        $this.sparkline('html', {
            type: 'pie',
            height: $this.data('height') ? $this.data('height') : '90',
            sliceColors: $this.data('color')
        });
    });

    // ------------------
    // - SPARKLINE LINE -
    // ------------------
    $('.sparkline').each(function () {
        var $this = $(this);
        $this.sparkline('html', {
            type: 'line',
            height: $this.data('height') ? $this.data('height') : '90',
            width: '100%',
            lineColor: $this.data('linecolor'),
            fillColor: $this.data('fillcolor'),
            spotColor: $this.data('spotcolor')
        });
    });
});


